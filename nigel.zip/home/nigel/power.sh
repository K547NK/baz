#!/bin/zsh
POWER=$(apm -l)
STATUS=$(apm -b)
CHARGE=$(apm -a)
charging=$()
unplugged=$()
if [ $CHARGE = 1  ];then
    echo -n $charging $POWER%
else
    echo -n $unplugged $POWER%
fi


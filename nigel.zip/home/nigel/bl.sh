#!/bin/sh
blue = $(#8c4b46)

